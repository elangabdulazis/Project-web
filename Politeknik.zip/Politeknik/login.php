<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>login</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/login.css">
    <link href="FontAwesome/css/all.css" rel="stylesheet">
  </head>
  <body>
    <div class="container">
      <h4 class="text-center">FORM LOGIN</h4>
      <hr>
      <form method="post">
        <div class="form-group">
          <label>Username</label>
          <div class="input-group">
            <div class="input-group-prepend">
              <div class="input-group-text"><i class="fas fa-user"></i></div>
            </div>
            <input type="text" class ="form-control" name="txtUsername" placeholder="Username">
          </div>
        </div>
        <div class="form-group">
          <label>Password</label>
          <div class="input-group">
            <div class="input-group-prepend">
              <div class="input-group-text"><i class="fas fa-unlock-alt"></i></div>
            </div>
            <input type="password" class ="form-control" name="txtPassword" placeholder="Password">
          </div>
        </div>
        <input type="submit" class="btn btn-primary button" name="btnSubmit" value="Submit">
        <input type="reset" class="btn btn-danger button" name="btnReset" value="Cancel">
      </form>
      <?php
        include('koneksi.php');
        if(isset($_POST['btnSubmit'])){
          $username = isset($_POST['txtUsername'])?$_POST['txtUsername']:"";
          $password = isset($_POST['txtPassword'])?md5($_POST['txtPassword']):"";
          $login = mysqli_query($koneksi,"select * from user where username = '$username' and password = '$password'");
          $cek=mysqli_num_rows($login); //Menghitung jumlah baris yang dihasilkan dari query
          if($cek==1){
            session_start();
            $data = mysqli_fetch_array($login);
            $_SESSION['user']=$data['username'];
            $_SESSION['level']=$data['level'];
            header("location:index.php");
          }else{
            echo "<script>alert('Username atau Password Salah')</script>";
          }
        }
       ?>
    </div>
  </body>
</html>
