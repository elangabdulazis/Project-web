<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Mahasiswa</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
  </head>
  <body>
    <?php
      $koneksi = mysqli_connect('localhost','root','','akademik');
      $ambil = mysqli_query($koneksi,"select * from mahasiswa where nim='$_GET[nim]'");
      $data_mhs = mysqli_fetch_array($ambil);
     ?>
    <div class="container">
      <h2>Edit Data Mahasiswa</h2>
      <form class="form-group mt-5" method="post">
        <div class="row mt-2">
          <div class="col-md-2">
            Nim
          </div>
          <div class="col-md-5">
            <input type="text" name="txtnim" class="form-control" value="<?php echo  $data_mhs['nim']?>" disabled>
          </div>
        </div>
        <div class="row mt-2">
          <div class="col-md-2">
            Nama
          </div>
          <div class="col-md-5">
            <input type="text" name="txtnama" class="form-control" value="<?php echo  $data_mhs['nama_mhs']?>" disabled>
          </div>
        </div>
        <div class="row mt-2">
          <div class="col-md-2">
            Jenis Kelamin
          </div>
          <div class="col-md-5">
            <input type="radio" name="jekel" value="L" <?php echo ($data_mhs['jekel']=='L')? 'checked':''?>>Laki-Laki
            <input type="radio" name="jekel" value="P"<?php echo ($data_mhs['jekel']=='P')? 'checked':''?>>Perempuan
          </div>
        </div>
        <div class="row mt-2">
          <div class="col-md-2">
            Email
          </div>
          <div class="col-md-5">
            <input type="email" name="txtemail" class="form-control" value="<?php echo  $data_mhs['email']?>">
          </div>
        </div>
        <div class="row mt-2">
          <div class="col-md-2">
            Nama Jurusan
          </div>
          <div class="col-md-5">
            <select class="form-control" name="idjurusan">
              <?php
                  $koneksi = mysqli_connect('localhost','root','','akademik');
                  $data = mysqli_query($koneksi,"select * from jurusan");
                  while ($row=mysqli_fetch_array($data)) {
                  echo "<option value =$row[id_jurusan]>".$row['nama_jurusan']."</option>";
                  }
              ?>
            </select>
          </div>
        </div>
        <div class="row mt-2">
          <div class="col-md-2">
            Nama Prodi
          </div>
          <div class="col-md-5">
            <select class="form-control" name="idprodi">
              <?php
                  $koneksi = mysqli_connect('localhost','root','','akademik');
                  $data1 = mysqli_query($koneksi,"select * from prodi");
                  while ($row1=mysqli_fetch_array($data1)) {
                  echo "<option value = '$row1[nama_prodi]'>".$row1['nama_prodi']."</option>";
                  }
              ?>
            </select>
          </div>
        </div>
        <div class="row mt-2">
          <div class="col-md-2">
            No Telpon
          </div>
          <div class="col-md-5">
            <input type="text" name="txtnotelp" class="form-control" value="<?php echo  $data_mhs['no_telp']?>">
          </div>
        </div>
        <div class="row mt-2">
          <div class="col-md-2">
            Alamat
          </div>
          <div class="col-md-5">
            <textarea name="txtalamat" rows="8" cols="80" class="form-control" placeholder="Masukan Alamat Anda!"></textarea>
          </div>
        </div>
        <div class="row mt-2">
          <div class="col-md-2">
            &nbsp;
          </div>
          <div class="col-md-5">
            <input type="submit" name="btnSubmit" value="Submit" class="btn btn-primary">
            <input type="reset" name="btnReset" value="Reset" class="btn btn-danger">
          </div>
        </div>
      </form>
    </div>
    <?php
        $koneksi = mysqli_connect('localhost','root','','akademik');
        $nim = $_GET['nim'];
        $nama = isset($_POST['txtnama'])?$_POST['txtnama']:'';
        $jekel = isset($_POST['jekel'])?$_POST['jekel']:'';
        $email = isset($_POST['txtemail'])?$_POST['txtemail']:'';
        $id_jurusan = isset($_POST['idjurusan'])?$_POST['idjurusan']:'';
        $id_prodi = isset($_POST['idprodi'])?$_POST['idprodi']:'';
        $notelp = isset($_POST['txtnotelp'])?$_POST['txtnotelp']:'';
        $alamat = isset($_POST['txtalamat'])?$_POST['txtalamat']:'';
        if(isset($_POST['btnSubmit'])){
            $simpan = mysqli_query($koneksi,"update mahasiswa set
            nama_mhs = '$nama',
            jekel = '$jekel',
            email = '$email',
            id_jurusan = $id_jurusan,
            id_prodi = $id_prodi,
            no_telp = '$notelp',
            alamat = '$alamat'
            where nim = $nim
            ");
            if($simpan){
                header('location:list_mahasiswa.php');
            }
        }
    ?>
  </body>
</html>
