<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>List Mahasiswa</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
  </head>
  <body>
    <div class="container">
      <table class="table table-bordered text-center mt-3">
        <tr>
          <th>NO</th>
          <th>NIM</th>
          <th>NAMA MAHASISWA</th>
          <th>JENIS KELAMIN</th>
          <th>EMAIL</th>
          <th>NAMA JURUSAN</th>
          <th>NAMA PRODI</th>
          <th>NO TELP</th>
          <th>ALAMAT</th>
          <th>ACTION</th>
        </tr>
          <?php
            $koneksi = mysqli_connect('localhost','root','','akademik');
            $data = mysqli_query($koneksi,"select * from mahasiswa
            INNER JOIN jurusan
            ON mahasiswa.id_jurusan = jurusan.id_jurusan
            JOIN prodi
            ON mahasiswa.id_prodi = prodi.id_prodi
            ");
            $i =1;
            while ($row=mysqli_fetch_array($data)) {
          ?>
          <tr>
            <td><?php echo $i?></td>
            <td><?php echo $row['nim']?></td>
            <td><?php echo $row['nama_mhs']?></td>
            <td><?php echo $row['jekel']?></td>
            <td><?php echo $row['email']?></td>
            <td><?php echo $row['nama_jurusan']?></td>
            <td><?php echo $row['nama_prodi']?></td>
            <td><?php echo $row['no_telp']?></td>
            <td><?php echo $row['alamat']?></td>
            <td>
              <a href="hapus_mahasiswa.php?nim=<?php echo $row['nim']?>" class="btn btn-danger" >Hapus
              <a href="edit_mahasiswa.php?nim=<?php echo $row['nim']?>" class="btn btn-primary">Edit
            </td>
          </tr>
          <?php $i++;}?>
      </table>
    </div>
  </body>
</html>
