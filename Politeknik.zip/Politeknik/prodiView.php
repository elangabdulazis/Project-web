        <?php
            $page= isset($_GET['page'])?$_GET['page']:'list';
            switch($page){
                case 'list':
        ?>
        <h1>List Prodi</h1>
        <p><a href="?p=prodi&page=entri" class="btn btn-primary"><i class="fas fa-save mr-2"></i>Tambah Prodi</a></p>
        <table class="table table-bordered text-center mt-3">
        <tr>
          <th>NO</th>
          <th>NAMA PRODI</th>
          <th>Jenjang</th>
          <th>NAMA JURUSAN</th>
          <th>ACTION</th>
        </tr>
          <?php
            $koneksi = mysqli_connect('localhost','root','','akademik');
            $data = mysqli_query($koneksi,"select * from prodi,jurusan where prodi.id_jurusan=jurusan.id_jurusan");
            $i =1;
            while ($row=mysqli_fetch_array($data)) {
          ?>
          <tr>
            <td><?php echo $i?></td>
            <td><?php echo $row['nama_prodi']?></td>
            <td><?php echo $row['jenjang']?></td>
            <td><?php echo $row['nama_jurusan']?></td>
            <td>
              <a href="prodiController.php?aksi=hapus&id_prodi=<?php echo $row['id_prodi']?>" class="btn btn-danger pr-2 pl-2"><i class="fas fa-trash mr-2"></i>Hapus</a>
              <a href="?p=prodi&page=update&id_prodi=<?php echo $row['id_prodi']?>" class="btn btn-primary ml-2 pr-2 pl-2"><i class="far fa-edit mr-2"></i>Edit</a>
            </td>
          </tr>
          <?php $i++;}?>
      </table>
      <?php
        break;
        case 'entri':
      ?>
      <h2>Input Prodi</h2>
      <form class="form-group mt-5" method="post" action="prodiController.php?aksi=tambah">
        <div class="row mt-2">
          <div class="col-md-2">
            Nama Prodi
          </div>
          <div class="col-md-5">
            <input type="text" name="txtNama" class="form-control" placeholder="Masukan Nama Prodi">
          </div>
        </div>
        <div class="row mt-2">
          <div class="col-md-2">
            Jenjang
          </div>
          <div class="col-md-5">
            <input type="text" name="txtJenjang" class="form-control" placeholder="Masukan Jenjang Prodi">
          </div>
        </div>
        <div class="row mt-2">
          <div class="col-md-2">
            Nama Jurusan
          </div>
          <div class="col-md-5">
            <select class="form-control" name="idjurusan">
              <?php
                  $data = mysqli_query($koneksi,"select * from jurusan");
                  while ($row=mysqli_fetch_array($data)) {
                  echo "<option value = $row[id_jurusan]>".$row['nama_jurusan']."</option>";
                  }
              ?>
            </select>
          </div>
        </div>
        <div class="row mt-2">
          <div class="col-md-2">
            &nbsp;
          </div>
          <div class="col-md-5">
            <input type="submit" name="btnSubmit" value="Submit" class="btn btn-primary">
            <input type="reset" name="btnReset" value="Reset" class="btn btn-danger">
          </div>
        </div>
      </form>
        <?php
            break;
            case 'update':
            include('koneksi.php');
            $ambil = mysqli_query($koneksi,"select * from prodi where id_prodi='$_GET[id_prodi]'");
            $data = mysqli_fetch_array($ambil);
        ?>
        <h2>Update Prodi</h2>
        <form class="form-group mt-5" method="post" action="prodiController.php?aksi=ubah&id_prodi=<?php echo $data['id_prodi']?>">
            <div class="row mt-2">
                <div class="col-md-2">
                    Nama Prodi
                </div>
                <div class="col-md-5">
                    <input type="text" name="txtNama" class="form-control" value="<?php echo $data['nama_prodi']?>">
                </div>
            </div>
            <div class="row mt-2">
                <div class="col-md-2">
                    Jenjang
                </div>
                <div class="col-md-5">
                    <input type="text" name="txtJenjang" class="form-control" value="<?php echo $data['jenjang']?>">
                </div>
            </div>
            <div class="row mt-2">
                <div class="col-md-2">
                    Nama Jurusan
                </div>
                <div class="col-md-5">
                    <select class="form-control" name="idjurusan">
                        <?php
                            $data = mysqli_query($koneksi,"select * from jurusan");
                            while ($row=mysqli_fetch_array($data)) {
                            echo "<option value = $row[id_jurusan]>".$row['nama_jurusan']."</option>";
                            }
                        ?>
                    </select>
                </div>
            </div>
            <div class="row mt-2">
                <div class="col-md-2">
                    &nbsp;
                </div>
                <div class="col-md-5">
                    <input type="submit" name="btnSubmit" value="Submit" class="btn btn-primary">
                    <input type="reset" name="btnReset" value="Reset" class="btn btn-danger">
                </div>
            </div>
        </form>
      <?php
        break;
        }
      ?>
