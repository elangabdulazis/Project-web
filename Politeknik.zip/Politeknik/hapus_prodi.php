<?php
    $koneksi = mysqli_connect('localhost','root','','akademik');
    $hapus = mysqli_query($koneksi,"delete from prodi where id_prodi='$_GET[id_prodi]'");
    if($hapus){
        header('location:list_prodi.php');
    }
?>