<?php
    include('koneksi.php');
    if($_GET['aksi']=='tambah'){
        $nama = isset($_POST['txtNama'])?$_POST['txtNama']:'';
        $jenjang = isset($_POST['txtJenjang'])?$_POST['txtJenjang']:'';
        $id_jurusan = isset($_POST['idjurusan'])?$_POST['idjurusan']:'';
        if(isset($_POST['btnSubmit'])){
          $simpan = mysqli_query($koneksi,"insert into prodi values(0,'$nama','$jenjang',$id_jurusan)");
          if($simpan){
            header('location:index.php?p=prodi');
          }
        }
    }
    else if($_GET['aksi']=='ubah'){
        $id = $_GET['id_prodi'];
        $nama = isset($_POST['txtNama'])?$_POST['txtNama']:'';
        $jenjang = isset($_POST['txtJenjang'])?$_POST['txtJenjang']:'';
        $id_jurusan = isset($_POST['idjurusan'])?$_POST['idjurusan']:'';
        if(isset($_POST['btnSubmit'])){
            $simpan = mysqli_query($koneksi,
                "update prodi
                set nama_prodi ='$nama',
                jenjang = '$jenjang',
                id_jurusan =$id_jurusan where id_prodi=$id
            ");
            if($simpan){
                header('location:index.php?p=prodi');
            }
        }
    }
    else if($_GET['aksi']=='hapus'){
    $hapus = mysqli_query($koneksi,"delete from prodi where id_prodi='$_GET[id_prodi]'");
        if($hapus){
            header('location:index.php?p=prodi');
        }
    }
?>
