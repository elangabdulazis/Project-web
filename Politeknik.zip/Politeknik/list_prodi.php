<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>List Prodi</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
  </head>
  <body>
    <div class="container">
      <table class="table table-bordered text-center mt-3">
        <tr>
          <th>NO</th>
          <th>ID PRODI</th>
          <th>NAMA PRODI</th>
          <th>Jenjang</th>
          <th>NAMA JURUSAN</th>
          <th>ACTION</th>
        </tr>
          <?php
            $koneksi = mysqli_connect('localhost','root','','akademik');
            $data = mysqli_query($koneksi,"select * from prodi,jurusan where prodi.id_jurusan=jurusan.id_jurusan");
            $i =1;
            while ($row=mysqli_fetch_array($data)) {
          ?>
          <tr>
            <td><?php echo $i?></td>
            <td><?php echo $row['id_prodi']?></td>
            <td><?php echo $row['nama_prodi']?></td>
            <td><?php echo $row['jenjang']?></td>
            <td><?php echo $row['nama_jurusan']?></td>
            <td>
              <a href="hapus_prodi.php?id_prodi=<?php echo $row['id_prodi']?>" class="btn btn-danger pr-2 pl-2">Hapus
              <a href="edit_prodi.php?id_prodi=<?php echo $row['id_prodi']?>" class="btn btn-primary ml-2 pr-2 pl-2">Edit
            </td>
          </tr>
          <?php $i++;}?>
      </table>
    </div>
  </body>
</html>
