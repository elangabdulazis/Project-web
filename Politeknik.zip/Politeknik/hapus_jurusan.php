<?php
    $koneksi = mysqli_connect('localhost','root','','akademik');
    $hapus = mysqli_query($koneksi,"delete from jurusan where id_jurusan='$_GET[id_jurusan]'");
    if($hapus){
        header('location:list_jurusan.php');
    }
?>
