      <?php
        $page = isset($_GET['page'])?$_GET['page']:'list';
        switch ($page) {
          case 'list':
      ?>
      <h1>List User</h1>
      <p><a href="?p=user&page=entri" class="btn btn-primary"><i class="fas fa-save mr-2"></i>Tambah User</a></p>
      <table class="table table-bordered text-center mt-3">
        <tr>
          <th>NO</th>
          <th>Username</th>
          <th>Level</th>
          <th>ACTION</th>
        </tr>
        <?php
          $data = mysqli_query($koneksi,"select * from user");
          $i =1;
          while ($row=mysqli_fetch_array($data)) {
            ?>
            <tr>
              <td><?php echo $i?></td>
              <td><?php echo $row['username']?></td>
              <td><?php echo $row['level']?></td>
              <td>
                <a href="userController.php?aksi=hapus&username=<?php echo $row['username']?>" class="btn btn-danger pr-2 pl-2" onclick="return confirm('Anda yakin ingin menghapus')"><i class="fas fa-trash mr-2"></i>Hapus</a>
                <a href="?p=user&page=update&username=<?php echo $row['username']?>" class="btn btn-primary ml-2 pr-2 pl-2"><i class="far fa-edit mr-2"></i>Edit</a>
              </td>
            </tr>
            <?php $i++;}?>
        </table>
        <?php
          break;
          case 'entri':
        ?>
        <h2>Input User</h2>
        <form class="form-group mt-5" method="post" action="userController.php?aksi=tambah">
          <div class="row mt-2">
            <div class="col-md-2">
              Username
            </div>
            <div class="col-md-5">
              <input type="text" name="txtUsername" class="form-control" placeholder="Masukan Username Anda">
            </div>
          </div>
          <div class="row mt-2">
            <div class="col-md-2">
              Password
            </div>
            <div class="col-md-5">
              <input type="password" name="txtPassword" class="form-control" placeholder="Masukan Password Anda">
            </div>
          </div>
          <div class="row mt-2">
            <div class="col-md-2">
              Level
            </div>
            <div class="col-md-5">
              <select class="form-control" name="level">
                <option value="Admin">Admin</option>
                <option value="Anggota">Anggota</option>
              </select>
            </div>
          </div>
          <div class="row mt-2">
            <div class="col-md-2">
              &nbsp;
            </div>
            <div class="col-md-5">
              <input type="submit" name="btnSubmit" value="Submit" class="btn btn-primary">
              <input type="reset" name="btnReset" value="Reset" class="btn btn-danger">
            </div>
          </div>
        </form>
        <?php
          break;
          case 'update':
          $ambil = mysqli_query($koneksi,"select * from user where username='$_GET[username]'");
          $data = mysqli_fetch_array($ambil);
        ?>
        <h2>Update User</h2>
        <form class="form-group mt-5" method="post" action="userController.php?aksi=ubah&username=<?php echo $data['username']?>">
          <div class="row mt-2">
            <div class="col-md-2">
              Username
            </div>
            <div class="col-md-5">
              <input type="text" name="txtUsername" class="form-control" value="<?php  echo $data['username'];?>">
            </div>
          </div>
          <div class="row mt-2">
            <div class="col-md-2">
              Password
            </div>
            <div class="col-md-5">
              <input type="password" name="txtPassword" class="form-control" value="<?php  echo $data['password'];?>">
            </div>
          </div>
          <div class="row mt-2">
            <div class="col-md-2">
              Level
            </div>
            <div class="col-md-5">
              <select class="form-control" name="level">
                <option value="Admin">Admin</option>
                <option value="Anggota">Anggota</option>
              </select>
            </div>
          </div>
          <div class="row mt-2">
            <div class="col-md-2">
              &nbsp;
            </div>
            <div class="col-md-5">
              <input type="submit" name="btnSubmit" value="Submit" class="btn btn-primary">
              <input type="reset" name="btnReset" value="Reset" class="btn btn-danger">
            </div>
          </div>
        </form>
        <?php
          break;
          }
        ?>
