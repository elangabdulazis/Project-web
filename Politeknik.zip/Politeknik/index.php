<?php
  session_start();
  if(!isset($_SESSION['user'])){
      header("location:login.php");
  }else{
 ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Politeknik Negeri Padang</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link href="FontAwesome/css/all.css" rel="stylesheet">
	<script src="jquery.min.js"></script>
    <style>
      ul{
        padding: 0;
      }
      ul li{
        margin-top: 7px;
      }
      ul li a{
        display: block;
        padding: 5px 40px;
        text-align: center;
        background:#4d76ff;
        color: white;
        border-radius: 10px;
      }
      ul li a:hover{
        background: #0040ff;
        color: white;
        font-weight: bold;
        text-decoration: none;
      }
    </style>
  </head>
  <body>
    <div class="container">
      <div class="row" style="padding-top:10px">
        <div class="col-md-2" style="background-color: #1a4fff;min-height:200px;border-radius:3px; color:white"><h3>Menu</h3>
          <?php
            if($_SESSION['level']=='Admin'){
              include('MenuAdmin.php');
            }
            elseif($_SESSION['level']=='Anggota'){
              include('MenuAnggota.php');
            }
          ?>
        </div>
        <div class="col-md-10" style="min-height:200px;" >
          <?php
            include('main.php');
          ?>
        </div>
      </div>
    </div>
  </body>
</html>
<?php
  }
 ?>
