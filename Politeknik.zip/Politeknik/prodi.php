<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Prodi</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
  </head>
  <body>
    <div class="container">
      <h2>Input Prodi</h2>
      <form class="form-group mt-5" method="post">
        <div class="row mt-2">
          <div class="col-md-2">
            Nama Prodi
          </div>
          <div class="col-md-5">
            <input type="text" name="txtNama" class="form-control" placeholder="Masukan Nama Prodi">
          </div>
        </div>
        <div class="row mt-2">
          <div class="col-md-2">
            Jenjang
          </div>
          <div class="col-md-5">
            <input type="text" name="txtJenjang" class="form-control" placeholder="Masukan Jenjang Prodi">
          </div>
        </div>
        <div class="row mt-2">
          <div class="col-md-2">
            Nama Jurusan
          </div>
          <div class="col-md-5">
            <select class="form-control" name="idjurusan">
              <?php
                  include('koneksi.php')
                  $data = mysqli_query($koneksi,"select * from jurusan");
                  while ($row=mysqli_fetch_array($data)) {
                  echo "<option value = $row[id_jurusan]>".$row['nama_jurusan']."</option>";
                  }
              ?>
            </select>
          </div>
        </div>
        <div class="row mt-2">
          <div class="col-md-2">
            &nbsp;
          </div>
          <div class="col-md-5">
            <input type="submit" name="btnSubmit" value="Submit" class="btn btn-primary">
            <input type="reset" name="btnReset" value="Reset" class="btn btn-danger">
          </div>
        </div>
      </form>
    </div>
    <?php
    $nama = isset($_POST['txtNama'])?$_POST['txtNama']:'';
    $jenjang = isset($_POST['txtJenjang'])?$_POST['txtJenjang']:'';
    $id_jurusan = isset($_POST['idjurusan'])?$_POST['idjurusan']:'';
    if(isset($_POST['btnSubmit'])){
      $simpan = mysqli_query($koneksi,"insert into prodi values(0,'$nama','$jenjang',$id_jurusan)");
      if($simpan){
        header('location:list_prodi.php');
      }
    }
    ?>
  </body>
</html>
