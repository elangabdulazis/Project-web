<?php
    include('koneksi.php');
    if($_GET['aksi']=='tambah'){
		$nip = isset($_POST['txtNip'])?$_POST['txtNip']:'';
        $nama = isset($_POST['txtNama'])?$_POST['txtNama']:'';
        $email = isset($_POST['txtEmail'])?$_POST['txtEmail']:'';
        $jk = isset($_POST['jk'])?$_POST['jk']:'';
		$noTelp= isset($_POST['txtNotelp'])?$_POST['txtNotelp']:'';
		$alamat = isset($_POST['txtAlamat'])?$_POST['txtAlamat']:'';
        if(isset($_POST['btnSubmit'])){
          $simpan = mysqli_query($koneksi,"insert into dosen values('$nip','$nama','$email','$jk','$noTelp','$alamat')");
          if($simpan){
            header('location:index.php?p=dosen');
          }
        }
    }
    else if($_GET['aksi']=='ubah'){
        $nip = isset($_POST['txtNip'])?$_POST['txtNip']:'';
        $nama = isset($_POST['txtNama'])?$_POST['txtNama']:'';
        $email = isset($_POST['txtEmail'])?$_POST['txtEmail']:'';
        $jk = isset($_POST['jk'])?$_POST['jk']:'';
		$noTelp= isset($_POST['txtNotelp'])?$_POST['txtNotelp']:'';
		$alamat = isset($_POST['txtAlamat'])?$_POST['txtAlamat']:'';
        if(isset($_POST['btnSubmit'])){
            $simpan = mysqli_query($koneksi,
                "update dosen
                set nip ='$nip',
                nama = '$nama',
                email = '$email',
				jk = '$jk',
				no_telp = '$noTelp',
				alamat = '$alamat' where nip='$nip'");
            if($simpan){
                header('location:index.php?p=dosen');
            }
        }
    }
    else if($_GET['aksi']=='hapus'){
    $hapus = mysqli_query($koneksi,"delete from dosen where nip='$_GET[nip]'");
        if($hapus){
            header('location:index.php?p=dosen');
        }
    }
?>
