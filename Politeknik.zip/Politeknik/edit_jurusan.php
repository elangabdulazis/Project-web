<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Jurusan</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
  </head>
  <body>
    <?php
      $ambil = mysqli_query($koneksi,"select * from jurusan where id_jurusan='$_GET[id_jurusan]'");
      $data = mysqli_fetch_array($ambil);
     ?>
     <div class="container">
       <h2>Input Jurusan</h2>
       <form class="form-group mt-5" method="post">
         <div class="row mt-2">
           <div class="col-md-2">
             Nama Jurusan
           </div>
           <div class="col-md-5">
             <input type="text" name="txtNama" class="form-control" value="<?php  echo $data['nama_jurusan']?>">
           </div>
         </div>
         <div class="row mt-2">
           <div class="col-md-2">
             Keterangan
           </div>
           <div class="col-md-5">
             <textarea name="txtKeterangan" rows="8" cols="80" class="form-control"><?php  echo $data['keterangan']?></textarea>
           </div>
         </div>
         <div class="row mt-2">
           <div class="col-md-2">
             &nbsp;
           </div>
           <div class="col-md-5">
             <input type="submit" name="btnSubmit" value="Submit" class="btn btn-primary">
             <input type="reset" name="btnReset" value="Reset" class="btn btn-danger">
           </div>
         </div>
       </form>
     </div>
    <?php
      $koneksi = mysqli_connect('localhost','root','','akademik');
      $id = $_GET['id_jurusan'];
      $nama = isset($_POST['txtNama'])?$_POST['txtNama']:'';
      $keterangan = isset($_POST['txtKeterangan'])?$_POST['txtKeterangan']:'';
      if(isset($_POST['btnSubmit'])){
        $edit = mysqli_query($koneksi,
        "update jurusan
        set nama_jurusan = '$nama',
        keterangan = '$keterangan'
        where id_jurusan = $id
        ");
        if($edit){
          header('location:list_jurusan.php');
        };
      }
    ?>
  </body>
</html>
