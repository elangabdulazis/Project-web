        <?php
            $page= isset($_GET['page'])?$_GET['page']:'list';
            switch($page){
                case 'list':
        ?>
        <h1>List Dosen</h1>
        <p><a href="?p=dosen&page=entri" class="btn btn-primary"><i class="fas fa-save mr-2"></i>Tambah Data Dosen</a></p>
        <table class="table table-bordered text-center mt-3">
        <tr>
		  <th>No</th>
          <th>NIP</th>
          <th>Nama</th>
          <th>E-mail</th>
          <th>JK</th>
          <th>No Telp</th>
          <th>Alamat</th>
		  <th>Action</th>
        </tr>
          <?php
            $koneksi = mysqli_connect('localhost','root','','akademik');
            $data = mysqli_query($koneksi,"select * from dosen");
            $i =1;
            while ($row=mysqli_fetch_array($data)) {
          ?>
          <tr>
            <td><?php echo $i?></td>
            <td><?php echo $row['nip']?></td>
            <td><?php echo $row['nama']?></td>
            <td><?php echo $row['email']?></td>
            <td><?php echo $row['jk']?></td>
			<td><?php echo $row['no_telp']?></td>
			<td><?php echo $row['alamat']?></td>
            <td>
              <a href="dosenController.php?aksi=hapus&nip=<?php echo $row['nip']?>" class="btn btn-danger pr-2 pl-2"><i class="fas fa-trash mr-2"></i>Hapus</a>
              <a href="?p=dosen&page=update&nip=<?php echo $row['nip']?>" class="btn btn-primary ml-2 pr-2 pl-2"><i class="far fa-edit mr-2"></i>Edit</a>
            </td>
          </tr>
          <?php $i++;}?>
      </table>
      <?php
        break;
        case 'entri':
      ?>
      <h2>Input Data Dosen</h2>
      <form class="form-group mt-5" method="post" action="dosenController.php?aksi=tambah">
        <div class="row mt-2">
          <div class="col-md-2">
            NIP
          </div>
          <div class="col-md-5">
            <input type="text" name="txtNip" class="form-control" placeholder="Masukan NIP">
          </div>
        </div>
		
        <div class="row mt-2">
          <div class="col-md-2">
            Nama
          </div>
          <div class="col-md-5">
            <input type="text" name="txtNama" class="form-control" placeholder="Masukan Nama">
          </div>
        </div>
		
		<div class="row mt-2">
          <div class="col-md-2">
            Email
          </div>
          <div class="col-md-5">
            <input type="text" name="txtEmail" class="form-control" placeholder="Masukan Email">
          </div>
        </div>
		
        <div class="row mt-2">
                <div class="col-md-2">
                    Jenis Kelamin
                </div>
                <div class="col-md-5">
                    <input type="radio" name="jk" value="L">Laki-Laki
                    <input type="radio" name="jk" value="P">Perempuan
                </div>
            </div>

		<div class="row mt-2">
          <div class="col-md-2">
            No Telp
          </div>
          <div class="col-md-5">
            <input type="text" name="txtNotelp" class="form-control" placeholder="Masukan No Telp">
          </div>
        </div>
		
		<div class="row mt-2">
          <div class="col-md-2">
            Alamat
          </div>
          <div class="col-md-5">
            <input type="text" name="txtAlamat" class="form-control" placeholder="Masukan Alamat">
          </div>
        </div>
		
        <div class="row mt-2">
          <div class="col-md-2">
            &nbsp;
          </div>
          <div class="col-md-5">
            <input type="submit" name="btnSubmit" value="Submit" class="btn btn-primary">
            <input type="reset" name="btnReset" value="Reset" class="btn btn-danger">
          </div>
        </div>
      </form>
        <?php
            break;
            case 'update':
            include('koneksi.php');
            $ambil = mysqli_query($koneksi,"select * from dosen where nip='$_GET[nip]'");
            $data = mysqli_fetch_array($ambil);
        ?>
        <h2>Update Data Dosen</h2>
			<form class="form-group mt-5" method="post" action="dosenController.php?aksi=ubah&nip=<?php echo $data['nip']?>">
				<form class="form-group mt-5" method="post" action="dosenController.php?aksi=ubah">
			<div class="row mt-2">
			  <div class="col-md-2">
				NIP
			  </div>
			  <div class="col-md-5">
				<input type="text" name="txtNip" class="form-control" value="<?php echo $data['nip']?>">
			  </div>
			</div>
			
			<div class="row mt-2">
			  <div class="col-md-2">
				Nama
			  </div>
			  <div class="col-md-5">
				<input type="text" name="txtNama" class="form-control" value="<?php echo $data['nama']?>" >
			  </div>
			</div>
			
			<div class="row mt-2">
			  <div class="col-md-2">
				Email
			  </div>
			  <div class="col-md-5">
				<input type="text" name="txtEmail" class="form-control" value="<?php echo $data['email']?>">
			  </div>
			</div>

			<div class="row mt-2">
                <div class="col-md-2">
                    Jenis Kelamin
                </div>
                <div class="col-md-5">
                    <input type="radio" name="jk" value="L" <?php echo ($data['jk']=='L')? 'checked':''?>>Laki-Laki
                    <input type="radio" name="jk" value="P" <?php echo ($data['jk']=='P')? 'checked':''?>>Perempuan
                </div>
            </div>
			
			<div class="row mt-2">
			  <div class="col-md-2">
				No Telp
			  </div>
			  <div class="col-md-5">
				<input type="text" name="txtNotelp" class="form-control" value="<?php echo $data['no_telp']?>">
			  </div>
			</div>
			
			<div class="row mt-2">
			  <div class="col-md-2">
				Alamat
			  </div>
			  <div class="col-md-5">
				<input type="text" name="txtAlamat" class="form-control" value="<?php echo $data['alamat']?>">
			  </div>
			</div>
            <div class="row mt-2">
                <div class="col-md-2">
                    &nbsp;
                </div>
                <div class="col-md-5">
                    <input type="submit" name="btnSubmit" value="Submit" class="btn btn-primary">
                    <input type="reset" name="btnReset" value="Reset" class="btn btn-danger">
                </div>
            </div>
        </form>
      <?php
        break;
        }
      ?>
