<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>List jurusan</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
  </head>
  <body>
    <div class="container">
      <table class="table table-bordered text-center mt-3">
        <tr>
          <th>NO</th>
          <th>ID JURUSAN</th>
          <th>NAMA JURUSAN</th>
          <th>KETERANGAN</th>
          <th>ACTION</th>
        </tr>
          <?php
            $koneksi = mysqli_connect('localhost','root','','akademik');
            $data = mysqli_query($koneksi,"select * from jurusan");
            $i =1;
            while ($row=mysqli_fetch_array($data)) {
          ?>
          <tr>
            <td><?php echo $i?></td>
            <td><?php echo $row['id_jurusan']?></td>
            <td><?php echo $row['nama_jurusan']?></td>
            <td><?php echo $row['keterangan']?></td>
            <td>
              <a href="hapus_jurusan.php?id_jurusan=<?php echo $row['id_jurusan']?>" class="btn btn-danger pr-2 pl-2">Hapus
              <a href="edit_jurusan.php?id_jurusan=<?php echo $row['id_jurusan']?>" class="btn btn-primary ml-2 pr-2 pl-2">Edit
            </td>
          </tr>
          <?php $i++;}?>
      </table>
    </div>
  </body>
</html>
