<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Prodi</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
  </head>
  <body>
    <?php
      $koneksi = mysqli_connect('localhost','root','','akademik');
      $ambil = mysqli_query($koneksi,"select * from prodi where id_prodi='$_GET[id_prodi]'");
      $data = mysqli_fetch_array($ambil);
     ?>
    <div class="container">
        <h2>Input Prodi</h2>
        <form class="form-group mt-5" method="post">
            <div class="row mt-2">
                <div class="col-md-2">
                    Nama Prodi
                </div>
                <div class="col-md-5">
                    <input type="text" name="txtNama" class="form-control" value="<?php echo $data['nama_prodi']?>">
                </div>
            </div>
            <div class="row mt-2">
                <div class="col-md-2">
                    Jenjang
                </div>
                <div class="col-md-5">
                    <input type="text" name="txtJenjang" class="form-control" value="<?php echo $data['jenjang']?>">
                </div>
            </div>
            <div class="row mt-2">
                <div class="col-md-2">
                    Nama Jurusan
                </div>
                <div class="col-md-5">
                    <select class="form-control" name="idjurusan">
                        <?php
                            $koneksi = mysqli_connect('localhost','root','','akademik');
                            $data = mysqli_query($koneksi,"select * from jurusan");
                            while ($row=mysqli_fetch_array($data)) {
                            echo "<option value = $row[id_jurusan]>".$row['nama_jurusan']."</option>";
                            }
                        ?>
                    </select>
                </div>
            </div>
            <div class="row mt-2">
                <div class="col-md-2">
                    &nbsp;
                </div>
                <div class="col-md-5">
                    <input type="submit" name="btnSubmit" value="Submit" class="btn btn-primary">
                    <input type="reset" name="btnReset" value="Reset" class="btn btn-danger">
                </div>
            </div>
        </form>
    </div>
    <?php
    $id = $_GET['id_prodi'];
    $koneksi = mysqli_connect('localhost','root','','akademik');
    $nama = isset($_POST['txtNama'])?$_POST['txtNama']:'';
    $jenjang = isset($_POST['txtJenjang'])?$_POST['txtJenjang']:'';
    $id_jurusan = isset($_POST['idjurusan'])?$_POST['idjurusan']:'';
    if(isset($_POST['btnSubmit'])){
      $simpan = mysqli_query($koneksi,
      "update prodi
      set nama_prodi ='$nama',
      jenjang = '$jenjang',
      id_jurusan =$id_jurusan where id_prodi=$id
      ");
      if($simpan){
        header('location:list_prodi.php');
      }
    }
    ?>
  </body>
</html>
