
      <?php
        $page =isset($_GET['page'])?$_GET['page']:'list';
        switch ($page) {
          case 'list':
      ?>
            <h1>List Jurusan</h1>
            <p><a href="?p=jur&page=entri" class="btn btn-primary"><i class="fas fa-save mr-2"></i>Tambah Jurusan</a></p>
            <table class="table table-bordered text-center mt-3">
              <tr>
                <th>NO</th>
                <th>NAMA JURUSAN</th>
                <th>KETERANGAN</th>
                <th>ACTION</th>
              </tr>
              <?php
                $data = mysqli_query($koneksi,"select * from jurusan");
                $i =1;
                while ($row=mysqli_fetch_array($data)) {
                  ?>
                  <tr>
                    <td><?php echo $i?></td>
                    <td><?php echo $row['nama_jurusan']?></td>
                    <td><?php echo $row['keterangan']?></td>
                    <td>
                      <?php
                        if($_SESSION['level']=='Anggota'){
                      ?>
                      <a href="jurusanController.php?aksi=hapus&id_jurusan=<?php echo $row['id_jurusan']?>" class="btn btn-danger pr-2 pl-2" onclick="return confirm('Anda yakin ingin menghapus')"><i class="fas fa-trash mr-2"></i>Hapus</a>
                      <?php
                        }
                      ?>
                      <a href="?p=jur&page=update&id_jurusan=<?php echo $row['id_jurusan']?>" class="btn btn-primary ml-2 pr-2 pl-2"><i class="far fa-edit mr-2"></i>Edit</a>
                    </td>
                  </tr>
                  <?php $i++;}?>
              </table>
              <?php
                break;
                case 'entri':
                ?>
                <h2>Input Jurusan</h2>
                <form class="form-group mt-5" method="post" action="jurusanController.php?aksi=tambah">
                  <div class="row mt-2">
                    <div class="col-md-2">
                      Nama Jurusan
                    </div>
                    <div class="col-md-5">
                      <input type="text" name="txtNama" class="form-control" placeholder="Masukan Nama Jurusan">
                    </div>
                  </div>
                  <div class="row mt-2">
                    <div class="col-md-2">
                      Keterangan
                    </div>
                    <div class="col-md-5">
                      <textarea name="txtKeterangan" rows="8" cols="80" class="form-control"></textarea>
                    </div>
                  </div>
                  <div class="row mt-2">
                    <div class="col-md-2">
                      &nbsp;
                    </div>
                    <div class="col-md-5">
                      <input type="submit" name="btnSubmit" value="Submit" class="btn btn-primary">
                      <input type="reset" name="btnReset" value="Reset" class="btn btn-danger">
                    </div>
                  </div>
                </form>
              <?php
                break;
                case 'update':
              $ambil = mysqli_query($koneksi,"select * from jurusan where id_jurusan='$_GET[id_jurusan]'");
              $data = mysqli_fetch_array($ambil);
                ?>
                <h2>Update Jurusan</h2>
                <form class="form-group mt-5" method="post" action="jurusanController.php?aksi=ubah&id_jurusan=<?php echo $data['id_jurusan']?>">
                  <div class="row mt-2">
                    <div class="col-md-2">
                      Nama Jurusan
                    </div>
                    <div class="col-md-5">
                      <input type="text" name="txtNama" class="form-control" value="<?php  echo $data['nama_jurusan']?>">
                    </div>
                  </div>
                  <div class="row mt-2">
                    <div class="col-md-2">
                      Keterangan
                    </div>
                    <div class="col-md-5">
                      <textarea name="txtKeterangan" rows="8" cols="80" class="form-control"><?php  echo $data['keterangan']?></textarea>
                    </div>
                  </div>
                  <div class="row mt-2">
                    <div class="col-md-2">
                      &nbsp;
                    </div>
                    <div class="col-md-5">
                      <input type="submit" name="btnSubmit" value="Submit" class="btn btn-primary">
                      <input type="reset" name="btnReset" value="Reset" class="btn btn-danger">
                    </div>
                  </div>
                </form>
                <?php
                  break;
                  }
                ?>
