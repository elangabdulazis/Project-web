<?php
    $koneksi = mysqli_connect('localhost','root','','akademik');
    $hapus = mysqli_query($koneksi,"delete from mahasiswa where nim='$_GET[nim]'");
    if($hapus){
        header('location:list_mahasiswa.php');
    }
?>
