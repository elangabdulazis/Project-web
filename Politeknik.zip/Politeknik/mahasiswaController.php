<?php
    include('koneksi.php');
    if($_GET['aksi']=='tambah'){
        $nim = isset($_POST['txtnim'])?$_POST['txtnim']:'';
        $nama = isset($_POST['txtnama'])?$_POST['txtnama']:'';
        $jekel = isset($_POST['jekel'])?$_POST['jekel']:'';
        $email = isset($_POST['txtemail'])?$_POST['txtemail']:'';
        $id_jurusan = isset($_POST['idjurusan'])?$_POST['idjurusan']:'';
        $id_prodi = isset($_POST['idprodi'])?$_POST['idprodi']:'';
        $notelp = isset($_POST['txtnotelp'])?$_POST['txtnotelp']:'';
        $alamat = isset($_POST['txtalamat'])?$_POST['txtalamat']:'';
        if(isset($_POST['btnSubmit'])){
            $simpan = mysqli_query($koneksi,"insert into mahasiswa values('$nim','$nama','$jekel','$email','$id_jurusan','$id_prodi','$notelp','$alamat')");
            if($simpan){
                header('location:index.php?p=mahasiswa');
            }
        }
    }
    else if($_GET['aksi']=='ubah'){
        $nim = $_GET['nim'];
        $nama = isset($_POST['txtnama'])?$_POST['txtnama']:'';
        $jekel = isset($_POST['jekel'])?$_POST['jekel']:'';
        $email = isset($_POST['txtemail'])?$_POST['txtemail']:'';
        $id_jurusan = isset($_POST['idjurusan'])?$_POST['idjurusan']:'';
        $id_prodi = isset($_POST['idprodi'])?$_POST['idprodi']:'';
        $notelp = isset($_POST['txtnotelp'])?$_POST['txtnotelp']:'';
        $alamat = isset($_POST['txtalamat'])?$_POST['txtalamat']:'';
        if(isset($_POST['btnSubmit'])){
            $simpan = mysqli_query($koneksi,"update mahasiswa set
            nama_mhs = '$nama',
            jekel = '$jekel',
            email = '$email',
            id_jurusan = $id_jurusan,
            id_prodi = $id_prodi,
            no_telp = '$notelp',
            alamat = '$alamat'
            where nim = $nim
            ");
            if($simpan){
                header('location:index.php?p=mahasiswa');
            }
        }
    }
    else if($_GET['aksi']=='hapus'){
        $hapus = mysqli_query($koneksi,"delete from mahasiswa where nim='$_GET[nim]'");
        if($hapus){
            header('location:index.php?p=mahasiswa');
        }
    }
?>
