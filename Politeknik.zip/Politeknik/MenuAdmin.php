<ul type=none>
  <li> <a href ="index.php" ><i class="fas fa-home mr-2"></i>Home</a></li>
  <li><a href ="index.php?p=user"><i class="fas fa-user mr-2"></i>User</a></li>
  <li><a href ="index.php?p=mahasiswa">Mahasiswa</a></li>
  <li><a href ="index.php?p=prodi">Prodi</a></li>
  <li><a href ="index.php?p=jur">Jurusan</a></li>
  <li><a href ="index.php?p=dosen">Dosen</a></li>
  <li><a href ="logout.php">Logout</a></li>
</ul>
