<script>
$(document).ready(function(){
	$("#jurusan").change(function() {
		var jur=$("#jurusan").val();
		$.ajax( {
			url:"getProdi.php",
			data:"jurusan=" +jur,
			success:function(msg) {
				$("#prodi").html(msg);
			}
		});
	});
});
</script>
  <div class="container">
        <?php
            $page= isset($_GET['page'])?$_GET['page']:'list';
            switch($page){
                case 'list':
              ?>
                <h1>List Mahasiswa</h1>
                <p><a href="?p=mahasiswa&page=entri" class="btn btn-primary"><i class="fas fa-user mr-2"></i>Tambah Mahasiswa</a></p>
                <table class="table table-bordered text-center mt-3">
                    <tr>
                    <th>NO</th>
					<th>NIM</th>
                    <th>NAMA MAHASISWA</th>
                    <th>JENIS KELAMIN</th>
					<th>EMAIL</th>
					<th>NAMA JURUSAN</th>
                    <th>NAMA PRODI</th>
					<th>NO TELP</th>
					<th>ALAMAT</th>
                    <th>ACTION</th>
                    </tr>
                    <?php
                        $data = mysqli_query($koneksi,"select * from mahasiswa INNER JOIN jurusan 
						ON mahasiswa.id_jurusan = jurusan.id_jurusan
						JOIN prodi
						ON mahasiswa.id_prodi = prodi.id_prodi
                        ");
                        $i =1;
                        while ($row=mysqli_fetch_array($data)) {
                    ?>
                    <tr>
                        <td><?php echo $i?></td>
						<td><?php echo $row['nim']?></td>
                        <td><?php echo $row['nama_mhs']?></td>
                        <td><?php echo $row['jekel']?></td>
						<td><?php echo $row['email']?></td>
						<td><?php echo $row['nama_jurusan']?></td>
                        <td><?php echo $row['nama_prodi']?></td>
						<td><?php echo $row['no_telp']?></td>
						<td><?php echo $row['alamat']?></td>
                        <td>
                        <?php
                          if($_SESSION['level']=="Admin"){
                         ?>
                        <a href="mahasiswaController.php?aksi=hapus&nim=<?php echo $row['nim']?>" class="btn btn-danger" ><i class="fas fa-trash mr-2"></i>Hapus
                          <?php
                            }
                           ?>
                        <a href="?p=mahasiswa&page=update&nim=<?php echo $row['nim']?>" class="btn btn-primary"><i class="far fa-edit mr-2"></i>Edit
                        </td>
                    </tr>
                    <?php $i++;}?>
                </table>
                <?php
                    break;
                    case 'entri':
                ?>
                    <h2>Input Data Mahasiswa</h2>
                    <form class="form-group mt-5" method="post" action="mahasiswaController.php?aksi=tambah">
                        <div class="row mt-2">
                            <div class="col-md-2">
                                Nim
                            </div>
                            <div class="col-md-5">
                                <input type="text" name="txtnim" class="form-control" placeholder="Masukan Nim Anda!">
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-md-2">
                                Nama
                            </div>
                            <div class="col-md-5">
                                <input type="text" name="txtnama" class="form-control" placeholder="Masukan Nama Anda!">
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-md-2">
                                Jenis Kelamin
                            </div>
                            <div class="col-md-5">
                                <input type="radio" name="jekel" value="L">Laki-Laki
                                <input type="radio" name="jekel" value="P">Perempuan
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-md-2">
                                Email
                            </div>
                            <div class="col-md-5">
                                <input type="email" name="txtemail" class="form-control" placeholder="Masukan Email Anda!">
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-md-2">
                                Jurusan
                            </div>
                            <div class="col-md-5">
                                <select class="form-control" name="idjurusan" id="jurusan">
                                    <?php
                                        $data = mysqli_query($koneksi,"select * from jurusan");
                                        while ($row=mysqli_fetch_array($data)) {
                                        echo "<option value =$row[id_jurusan]>".$row['nama_jurusan']."</option>";
                                        }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-md-2">
                                Nama Prodi
                            </div>
                            <div class="col-md-5">
                                <select class="form-control" name="idprodi" id="prodi">
								<option>---Pilih Prodi---</option>
                                    
                                </select>
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-md-2">
                                No Telpon
                            </div>
                            <div class="col-md-5">
                                <input type="text" name="txtnotelp" class="form-control" placeholder="Masukan No Telpon Anda!">
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-md-2">
                                Alamat
                            </div>
                            <div class="col-md-5">
                                <textarea name="txtalamat" rows="8" cols="80" class="form-control" placeholder="Masukan Alamat Anda!"></textarea>
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-md-2">
                                &nbsp;
                            </div>
                            <div class="col-md-5">
                                <input type="submit" name="btnSubmit" value="Submit" class="btn btn-primary">
                                <input type="reset" name="btnReset" value="Reset" class="btn btn-danger">
                            </div>
                        </div>
                    </form>
                    <?php
                        break;
                        case 'update':
                        $ambil = mysqli_query($koneksi,"select * from mahasiswa where nim='$_GET[nim]'");
                        $data_mhs = mysqli_fetch_array($ambil);
                    ?>
                    <h2>Edit Data Mahasiswa</h2>
                    <form class="form-group mt-5" method="post" action="mahasiswaController.php?aksi=ubah&nim=<?php echo $data_mhs['nim']?>">
                        <div class="row mt-2">
                            <div class="col-md-2">
                                Nim
                            </div>
                            <div class="col-md-5">
                                <input type="text" name="txtnim" class="form-control" value="<?php echo  $data_mhs['nim']?>" disabled>
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-md-2">
                                Nama
                            </div>
                            <div class="col-md-5">
                                <input type="text" name="txtnama" class="form-control" value="<?php echo  $data_mhs['nama_mhs']?>" disabled>
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-md-2">
                                Jenis Kelamin
                            </div>
                            <div class="col-md-5">
                                <input type="radio" name="jekel" value="L" <?php echo ($data_mhs['jekel']=='L')? 'checked':''?>>Laki-Laki
                                <input type="radio" name="jekel" value="P"<?php echo ($data_mhs['jekel']=='P')? 'checked':''?>>Perempuan
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-md-2">
                                Email
                            </div>
                            <div class="col-md-5">
                                <input type="email" name="txtemail" class="form-control" value="<?php echo  $data_mhs['email']?>">
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-md-2">
                                Nama Jurusan
                            </div>
                            <div class="col-md-5">
                                <select class="form-control" name="idjurusan" id="jurusan">
                                <?php
                                    $data = mysqli_query($koneksi,"select * from jurusan");
                                    while ($row=mysqli_fetch_array($data)) {
                                    echo "<option value =$row[id_jurusan]>".$row['nama_jurusan']."</option>";
                                    }
                                ?>
                                </select>
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-md-2">
                                Nama Prodi
                            </div>
                            <div class="col-md-5">
                                <select class="form-control" name="idprodi" id="prodi">
                                <?php
                                    $data1 = mysqli_query($koneksi,"select * from prodi");
                                    while ($row1=mysqli_fetch_array($data1)) {
                                    echo "<option value = '$row1[id_prodi]'>".$row1['nama_prodi']."</option>";
                                    }
                                ?>
                                </select>
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-md-2">
                                No Telpon
                            </div>
                            <div class="col-md-5">
                                <input type="text" name="txtnotelp" class="form-control" value="<?php echo  $data_mhs['no_telp']?>">
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-md-2">
                                Alamat
                            </div>
                            <div class="col-md-5">
                                <textarea name="txtalamat" rows="8" cols="80" class="form-control"><?php echo  $data_mhs['alamat']?></textarea>
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-md-2">
                                &nbsp;
                            </div>
                            <div class="col-md-5">
                                <input type="submit" name="btnSubmit" value="Submit" class="btn btn-primary">
                                <input type="reset" name="btnReset" value="Reset" class="btn btn-danger">
                            </div>
                        </div>
                    </form>
                <?php
                    break;
                    }
                ?>
