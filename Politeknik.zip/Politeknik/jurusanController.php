<?php
include('koneksi.php');
  if($_GET['aksi']=='tambah'){
    $nama = isset($_POST['txtNama'])?$_POST['txtNama']:'';
    $keterangan = isset($_POST['txtKeterangan'])?$_POST['txtKeterangan']:'';
    if(isset($_POST['btnSubmit'])){
      $simpan = mysqli_query($koneksi,"insert into jurusan values(0,'$nama','$keterangan')");
      if($simpan){
        header('location:index.php?p=jur');
      }
    }
  }
  else if($_GET['aksi']=='ubah'){
    $id = $_GET['id_jurusan'];
    $nama = isset($_POST['txtNama'])?$_POST['txtNama']:'';
    $keterangan = isset($_POST['txtKeterangan'])?$_POST['txtKeterangan']:'';
    if(isset($_POST['btnSubmit'])){
      $edit = mysqli_query($koneksi,
      "update jurusan
      set nama_jurusan = '$nama',
      keterangan = '$keterangan'
      where id_jurusan = $id
      ");
      if($edit){
        header('location:index.php?p=jur');
      };
    }
  }
  else if($_GET['aksi']=='hapus'){
    $hapus = mysqli_query($koneksi,"delete from jurusan where id_jurusan='$_GET[id_jurusan]'");
    if($hapus){
        header('location:index.php?p=jur');
    }
  }
?>
