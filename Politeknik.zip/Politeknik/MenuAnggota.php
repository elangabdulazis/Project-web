<ul type=none>
  <li><a href ="index.php">Home</a></li>
  <li><a href ="index.php?p=mahasiswa">Mahasiswa</a></li>
  <li><a href ="index.php?p=prodi">Prodi</a></li>
  <li><a href ="index.php?p=jur">Jurusan</a></li>
  <li><a href ="logout.php">Logout</a></li>
</ul>
