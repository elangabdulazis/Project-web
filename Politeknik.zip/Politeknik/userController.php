<?php
include('koneksi.php');
  if($_GET['aksi']=='tambah'){
    $username = isset($_POST['txtUsername'])?$_POST['txtUsername']:'';
    $password = isset($_POST['txtPassword'])?$_POST['txtPassword']:'';
    $level = isset($_POST['level'])?$_POST['level']:'';
    if(isset($_POST['btnSubmit'])){
      $simpan = mysqli_query($koneksi,"insert into user values('$username',md5('$password'),'$level')");
      if($simpan){
        header('location:index.php?p=user');
      }
    }
  }
  else if($_GET['aksi']=='ubah'){
    $username = $_GET['username'];
    $password = isset($_POST['txtPassword'])?$_POST['txtPassword']:'';
    $level = isset($_POST['level'])?$_POST['level']:'';
    if(isset($_POST['btnSubmit'])){
      $edit = mysqli_query($koneksi,
      "update user
      set password = md5('$password'),
      level = '$level'
      where username = '$username'
      ");
      if($edit){
        header('location:index.php?p=user');
      };
    }
  }
  else if($_GET['aksi']=='hapus'){
    $hapus = mysqli_query($koneksi,"delete from user where username='$_GET[username]'");
    if($hapus){
        header('location:index.php?p=user');
    }
  }
?>
